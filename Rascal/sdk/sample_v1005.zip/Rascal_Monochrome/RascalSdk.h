/*
	RASCAL SDK HEADER FILE
	Created BY KEVX@11/7/2010

	RascalSdk.h
*/
#include <WinDef.h>

/*All plugins should implement the following interface*/

/*
	Parameters:
		pIn: pointer to the buffer of a frame.
		dwSize: size of the buffer.

	Diz:
		This function may never change the size of the buffer,
		otherwise something unexpected will happen
*/
#define IPlugin __declspec(dllexport)

//#pragma comment(linker, "/EXPORT:doProcess=_doProcess")
#ifdef __cplusplus
extern "C" {
#endif

IPlugin void doProcess(PBYTE pIn, DWORD dwSize);

#ifdef __cplusplus
}
#endif